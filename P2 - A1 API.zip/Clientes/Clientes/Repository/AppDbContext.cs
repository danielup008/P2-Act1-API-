﻿using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Producto> Productos { get; set; }
    public DbSet<Pedido> Pedidos { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Pedido>()
            .HasMany(p => p.Productos)
            .WithMany(p => p.Pedidos)
            .UsingEntity<Dictionary<string, object>>(
                "PedidoProductos",
                j => j.HasOne<Producto>().WithMany().HasForeignKey("ProductoId"),
                j => j.HasOne<Pedido>().WithMany().HasForeignKey("PedidoId"),
                j => j.HasKey("PedidoId", "ProductoId"));
    }
}
