-- Crear base de datos
CREATE DATABASE Clientes;
GO

USE Clientes;
GO

-- Crear tabla Usuario
CREATE TABLE Usuarios (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE
);
GO

-- Crear tabla Producto
CREATE TABLE Productos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Precio DECIMAL(18, 2) NOT NULL
);
GO

-- Crear tabla Pedido
CREATE TABLE Pedidos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    UsuarioId INT NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Id)
);
GO

-- Crear tabla intermedia PedidoProductos para la relaci�n muchos a muchos
CREATE TABLE PedidoProductos (
    PedidoId INT NOT NULL,
    ProductoId INT NOT NULL,
    PRIMARY KEY (PedidoId, ProductoId),
    FOREIGN KEY (PedidoId) REFERENCES Pedidos(Id),
    FOREIGN KEY (ProductoId) REFERENCES Productos(Id)
);
GO
